var classsrecord_1_1adler16 =
[
    [ "get", "classsrecord_1_1adler16.html#a41e5f31c6381ef3c6d97d0a56406cae9", null ],
    [ "next", "classsrecord_1_1adler16.html#aef48818682748e87ace711d5dea3e21a", null ],
    [ "nextbuf", "classsrecord_1_1adler16.html#a0e862e961fd1ef489a8b2333aff7e019", null ]
];