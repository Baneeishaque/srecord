var classsrecord_1_1adler32 =
[
    [ "get", "classsrecord_1_1adler32.html#a1f45c1abcf1d07392145ef2d21c22cc9", null ],
    [ "next", "classsrecord_1_1adler32.html#a6aeb280e35cfbd28325af99bd2f81313", null ],
    [ "nextbuf", "classsrecord_1_1adler32.html#a4fb34e81435307c07236377cd3af3c81", null ]
];