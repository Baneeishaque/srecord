var classsrecord_1_1input__file__gowin__fs =
[
    [ "~input_file_gowin_fs", "classsrecord_1_1input__file__gowin__fs.html#ac1e87de51d1244e6ddbf92ffea1b7fab", null ],
    [ "input_file_gowin_fs", "classsrecord_1_1input__file__gowin__fs.html#aa77eeab21840bcf3367cac7bbd7e6a18", null ],
    [ "input_file_gowin_fs", "classsrecord_1_1input__file__gowin__fs.html#aef74a8cbe6bca17b8e5918b3ae70a14e", null ],
    [ "operator=", "classsrecord_1_1input__file__gowin__fs.html#a3f162d09bdf880edacce71c239bf072f", null ],
    [ "read", "classsrecord_1_1input__file__gowin__fs.html#a54a8de99679090417ca39a65e7b44ece", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__gowin__fs.html#ab0a5b0d742749899ff78cac7084f01d1", null ],
    [ "format_option_number", "classsrecord_1_1input__file__gowin__fs.html#afa9b1d8a0a2ba1219e5dc844357bc3fa", null ]
];