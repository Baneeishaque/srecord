var classsrecord_1_1input__file__os65a =
[
    [ "~input_file_os65a", "classsrecord_1_1input__file__os65a.html#accb54b684462fc21804d6dbd1ba2f28e", null ],
    [ "input_file_os65a", "classsrecord_1_1input__file__os65a.html#a0c19a754d666fac9a741d7e3160dc144", null ],
    [ "input_file_os65a", "classsrecord_1_1input__file__os65a.html#a0ec8f612b2a421c0dea925fca51bbf18", null ],
    [ "input_file_os65a", "classsrecord_1_1input__file__os65a.html#a9cf126919cba8dc0badf0300e5361dd5", null ],
    [ "read", "classsrecord_1_1input__file__os65a.html#aafb3b094d2453659e54e09e3603a6b52", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__os65a.html#aa309040d4c471d998915f6e2682695c8", null ],
    [ "format_option_number", "classsrecord_1_1input__file__os65a.html#a4d769528ef614d26ae067ca1d8c12976", null ],
    [ "operator=", "classsrecord_1_1input__file__os65a.html#ae9fa5c1c33112713d5253aad21278aa7", null ],
    [ "read_inner", "classsrecord_1_1input__file__os65a.html#a5c4b4cb3538f3330fd5f46d3692c5587", null ],
    [ "seen_some_input", "classsrecord_1_1input__file__os65a.html#a7f149985fd3ced535a0bca9cf7b1cc3c", null ],
    [ "ignore_the_rest", "classsrecord_1_1input__file__os65a.html#a25570b6ca1ea37fb51c23ecf4bb04d7d", null ]
];