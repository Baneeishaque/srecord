var classsrecord_1_1input__file__logisim =
[
    [ "state_t", "classsrecord_1_1input__file__logisim.html#a70a086b9fd15e7c2283dcc6473adca14", [
      [ "state_line_one", "classsrecord_1_1input__file__logisim.html#a70a086b9fd15e7c2283dcc6473adca14a16f582e2521a707baee3331ae2ae7e84", null ],
      [ "state_line_two", "classsrecord_1_1input__file__logisim.html#a70a086b9fd15e7c2283dcc6473adca14a6a83daaae8ce1ed4c6b5aac565de4723", null ],
      [ "state_lines_of_data", "classsrecord_1_1input__file__logisim.html#a70a086b9fd15e7c2283dcc6473adca14a5fc71a0ae6f10e45754edbe359354391", null ]
    ] ],
    [ "~input_file_logisim", "classsrecord_1_1input__file__logisim.html#a0029edc2bf047b48ec6fe7fe5b09c9f3", null ],
    [ "input_file_logisim", "classsrecord_1_1input__file__logisim.html#adf2e3dffd2f5baa4fe99126a9f7de12a", null ],
    [ "input_file_logisim", "classsrecord_1_1input__file__logisim.html#aa5dc126e45bc1a4bea76c3e8dc3a413e", null ],
    [ "input_file_logisim", "classsrecord_1_1input__file__logisim.html#a669aba9841e5527fa46752fce50016b2", null ],
    [ "read", "classsrecord_1_1input__file__logisim.html#ad911123e231c0bd0c52359f4cdf43f8d", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__logisim.html#a20456cb2c5038edda586f57fcb2120df", null ],
    [ "format_option_number", "classsrecord_1_1input__file__logisim.html#afd4f7f7e96cf7011e67e551590a29bd0", null ],
    [ "operator=", "classsrecord_1_1input__file__logisim.html#ad60f0cc93e07c1fabbda362b600efd08", null ]
];