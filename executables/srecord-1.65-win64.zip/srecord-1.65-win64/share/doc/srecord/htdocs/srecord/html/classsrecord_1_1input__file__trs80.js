var classsrecord_1_1input__file__trs80 =
[
    [ "~input_file_trs80", "classsrecord_1_1input__file__trs80.html#a1fa0bdbede4b7831f1b8dc8ebef55e3b", null ],
    [ "input_file_trs80", "classsrecord_1_1input__file__trs80.html#a4e1e75c8b7ee0fdd886a31129010f435", null ],
    [ "read", "classsrecord_1_1input__file__trs80.html#af11d173bc9d33ef03e2326b68f959339", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__trs80.html#a76157c715e4b33b127cd81de48da5c14", null ],
    [ "is_binary", "classsrecord_1_1input__file__trs80.html#aadbbb201dc36607be776f5a9d34a32c5", null ],
    [ "format_option_number", "classsrecord_1_1input__file__trs80.html#a811beeaae2053625b02bf42eb480fa37", null ],
    [ "operator=", "classsrecord_1_1input__file__trs80.html#ab898596e26e2251fb5c5679e828297d1", null ]
];