var classsrecord_1_1input__file__spectrum =
[
    [ "~input_file_spectrum", "classsrecord_1_1input__file__spectrum.html#aca4802ee9c82052110af316fd50cc3fb", null ],
    [ "input_file_spectrum", "classsrecord_1_1input__file__spectrum.html#a7db3c70b381c0c165e000916ec623795", null ],
    [ "input_file_spectrum", "classsrecord_1_1input__file__spectrum.html#aca127e758391f4d0e9c9cebf4c087a59", null ],
    [ "read", "classsrecord_1_1input__file__spectrum.html#a82373f0b3d51fd9319bd98149d379830", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__spectrum.html#a4e51f3d9061c42b0607127e2e9c3c7c1", null ],
    [ "format_option_number", "classsrecord_1_1input__file__spectrum.html#ad8d07c976b0a0ea1c9de691a4615ec89", null ],
    [ "operator=", "classsrecord_1_1input__file__spectrum.html#afa006de20ec699d8b262914f31ed3530", null ]
];