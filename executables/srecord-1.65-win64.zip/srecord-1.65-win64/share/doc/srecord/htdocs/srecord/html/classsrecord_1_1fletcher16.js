var classsrecord_1_1fletcher16 =
[
    [ "fletcher16", "classsrecord_1_1fletcher16.html#a8cf91df6ea890ab9e91bece7e98cfdb5", null ],
    [ "get", "classsrecord_1_1fletcher16.html#aa8132f1e3ecffa597de11b95cfd2118f", null ],
    [ "next", "classsrecord_1_1fletcher16.html#a1b72e6e521f26ffe8f482fb935c77988", null ],
    [ "nextbuf", "classsrecord_1_1fletcher16.html#aece226f93baa4064a8134af8a649bcad", null ]
];